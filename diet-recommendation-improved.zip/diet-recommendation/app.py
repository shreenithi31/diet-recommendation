"""AI-Based Personalised Diet Recommendation — Streamlit dashboard.
Run with: python -m streamlit run app.py
"""
import sys
from pathlib import Path
from html import escape

import pandas as pd
import streamlit as st

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / "src"))
from nutrition import ACTIVITY_FACTORS, ALLERGENS, CONDITIONS, DIETS, GOALS, Profile
from recommender import DietRecommender
from report import DISCLAIMER, format_markdown, shopping_list, to_dataframe

st.set_page_config(
    page_title="NutriWise | Personalised Diet Planner",
    page_icon="🥗",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap');
:root { --nw-green:#176b52; --nw-mint:#eaf5ef; --nw-ink:#19352b; --nw-muted:#65766d; }
html, body, [class*="css"] { font-family:'DM Sans', sans-serif; }
.stApp { background: linear-gradient(180deg,#f7fbf8 0%,#ffffff 44%); }
.block-container { padding-top:1.6rem; padding-bottom:3rem; max-width:1440px; }
h1,h2,h3 { font-family:'Manrope',sans-serif; color:var(--nw-ink); }
.hero { background:linear-gradient(120deg,#123e32 0%,#176b52 55%,#6aa889 100%); padding:2rem 2.2rem; border-radius:24px; color:white; margin-bottom:1.25rem; box-shadow:0 12px 35px rgba(23,107,82,.14); }
.hero h1 { color:white; font-size:2.15rem; line-height:1.18; margin:0 0 .45rem 0; }
.hero p { color:#e4f4eb; margin:.25rem 0 0 0; font-size:1rem; }
.eyebrow { color:#c5e8d6; font-weight:700; letter-spacing:.14em; font-size:.72rem; text-transform:uppercase; margin-bottom:.65rem; }
.section-label { color:#176b52; font-size:.76rem; font-weight:800; letter-spacing:.1em; text-transform:uppercase; }
.metric-card { background:white; border:1px solid #e2ece6; border-radius:17px; padding:1rem 1.1rem; min-height:115px; box-shadow:0 4px 16px rgba(25,53,43,.035); }
.metric-label { color:#65766d; font-size:.82rem; font-weight:600; }
.metric-value { color:#19352b; font-family:'Manrope',sans-serif; font-size:1.7rem; font-weight:800; margin:.2rem 0; }
.metric-help { color:#74857c; font-size:.75rem; }
.info-card { background:#f0f8f3; border:1px solid #dceee2; border-radius:16px; padding:1rem 1.15rem; }
.meal-card { background:white; border:1px solid #e4ede7; border-radius:16px; padding:1rem 1.1rem; margin:.4rem 0 .8rem 0; }
.meal-title { color:#19352b; font-size:1.05rem; font-weight:800; }
.muted { color:#65766d; font-size:.88rem; }
.stButton>button[kind="primary"] { background:#176b52; border-color:#176b52; border-radius:11px; font-weight:700; min-height:2.8rem; }
.stDownloadButton>button { border-radius:10px; font-weight:600; }
[data-testid="stSidebar"] { background:#f0f7f2; }
[data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3 { color:#19352b; }
hr { border-color:#e5eee8; }
@media (max-width: 800px) { .hero { padding:1.4rem; } .hero h1 { font-size:1.65rem; } }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def get_recommender():
    return DietRecommender()

rec = get_recommender()
food_names = sorted(rec.foods["name"].tolist())
GOAL_LABELS = {"lose": "Lose weight", "maintain": "Maintain weight", "gain": "Gain weight / muscle"}
DIET_LABELS = {"vegan": "Vegan", "vegetarian": "Vegetarian", "eggetarian": "Eggetarian", "non-vegetarian": "Non-vegetarian"}
ACTIVITY_LABELS = {"sedentary": "Sedentary — mostly sitting", "light": "Light — 1–3 days/week", "moderate": "Moderate — 3–5 days/week", "active": "Active — 6–7 days/week", "very_active": "Very active — intense daily activity"}
ALLERGEN_LABELS = {"dairy":"Dairy","gluten":"Gluten","nuts":"Nuts","soy":"Soy","egg":"Egg","fish":"Fish","shellfish":"Shellfish","sesame":"Sesame"}
CONDITION_LABELS = {"diabetes":"Diabetes","hypertension":"High blood pressure","high_cholesterol":"High cholesterol"}

with st.sidebar:
    st.markdown("## 🥗 NutriWise")
    st.caption("Your personalised nutrition companion")
    st.divider()
    st.markdown("### 01 · About you")
    age = st.number_input("Age", min_value=10, max_value=90, value=28, step=1)
    sex = st.selectbox("Biological sex used for BMR estimate", ["female", "male"], format_func=lambda x: x.title())
    col_w, col_h = st.columns(2)
    with col_w:
        weight = st.number_input("Weight (kg)", 30.0, 250.0, 62.0, 0.5)
    with col_h:
        height = st.number_input("Height (cm)", 120.0, 230.0, 165.0, 0.5)
    activity = st.selectbox("Activity level", list(ACTIVITY_FACTORS), index=2, format_func=lambda x: ACTIVITY_LABELS[x])
    goal = st.selectbox("Your goal", GOALS, index=1, format_func=lambda x: GOAL_LABELS[x])
    diet = st.selectbox("Eating preference", list(DIETS), index=1, format_func=lambda x: DIET_LABELS[x])
    st.divider()
    st.markdown("### 02 · Food preferences")
    allergies = st.multiselect("Allergies / ingredients to exclude", ALLERGENS, format_func=lambda x: ALLERGEN_LABELS[x], help="Foods tagged with selected allergens will be excluded from the plan.")
    conditions = st.multiselect("Health considerations", CONDITIONS, format_func=lambda x: CONDITION_LABELS[x], help="These filters are simplified and do not replace clinical advice.")
    likes = st.multiselect("Foods you enjoy", food_names, help="The planner prioritises foods similar to your preferences.")
    dislikes = st.multiselect("Foods you do not want", food_names)
    st.divider()
    st.markdown("### 03 · Plan settings")
    days = st.slider("Plan length", 1, 7, 7, format="%d day(s)")
    seed = st.number_input("Plan variation", min_value=0, max_value=9999, value=7, help="Change this number to generate a different meal combination.")
    generate = st.button("✨ Generate my diet plan", type="primary", use_container_width=True)
    st.caption("Your profile is used only to create this local session's plan.")

st.markdown("""
<div class="hero">
  <div class="eyebrow">PERSONALISED NUTRITION · MADE SIMPLE</div>
  <h1>Eat well. Feel better.<br>One meal at a time.</h1>
  <p>Build a practical meal plan around your goals, food preferences and daily routine.</p>
</div>
""", unsafe_allow_html=True)

intro_a, intro_b = st.columns([1.55, 1])
with intro_a:
    st.markdown("### Your nutrition, thoughtfully planned")
    st.markdown("NutriWise combines estimated energy needs, food preferences and a machine-learning strategy selector to create a meal plan with portions and nutrition summaries.")
with intro_b:
    st.markdown("<div class='info-card'><b>How it works</b><br><span class='muted'>01 · Build your profile<br>02 · Filter foods to your preferences<br>03 · Generate meals and track nutrition<br>04 · Export your plan and shopping list</span></div>", unsafe_allow_html=True)

if not generate and "current_plan" not in st.session_state:
    st.markdown("---")
    st.markdown("### Start with your profile")
    st.info("Set your details in the left panel, then select **Generate my diet plan** to build your personalised plan.")
    a, b, c = st.columns(3)
    with a:
        st.markdown("<div class='metric-card'><div class='metric-label'>SMART PORTIONS</div><div class='metric-value'>⚖️</div><div class='metric-help'>Estimated portions aligned to daily targets</div></div>", unsafe_allow_html=True)
    with b:
        st.markdown("<div class='metric-card'><div class='metric-label'>FOOD PREFERENCES</div><div class='metric-value'>🥑</div><div class='metric-help'>Filter by diet type, allergies and dislikes</div></div>", unsafe_allow_html=True)
    with c:
        st.markdown("<div class='metric-card'><div class='metric-label'>WEEKLY OVERVIEW</div><div class='metric-value'>📈</div><div class='metric-help'>Review calories, macros and shopping list</div></div>", unsafe_allow_html=True)
    st.caption(DISCLAIMER)
    st.stop()

if generate:
    profile = Profile(age, sex, weight, height, activity, goal, diet, allergies, conditions, likes, dislikes)
    try:
        with st.spinner("Building your personalised meal plan…"):
            st.session_state.current_plan = rec.generate(profile, days=days, seed=int(seed))
            st.session_state.current_profile_signature = (age, sex, weight, height, activity, goal, diet, tuple(allergies), tuple(conditions), tuple(likes), tuple(dislikes), days, int(seed))
    except ValueError as e:
        st.error(str(e))
        st.stop()

plan = st.session_state.get("current_plan")
if not plan:
    st.stop()

t = plan["targets"]
for warning in t["warnings"]:
    st.warning(warning)

st.markdown("---")
st.markdown("<div class='section-label'>YOUR SNAPSHOT</div>", unsafe_allow_html=True)
st.markdown("### Your daily nutrition targets")
metrics = [
    ("Daily energy", f"{t['calories']:,}", "kcal / day"),
    ("Body mass index", f"{t['bmi']:.1f}", t["bmi_category"]),
    ("Protein", f"{t['protein']} g", "daily target"),
    ("Carbohydrates", f"{t['carbs']} g", "daily target"),
    ("Healthy fats", f"{t['fat']} g", "daily target"),
]
cols = st.columns(5)
for col, (label, value, help_text) in zip(cols, metrics):
    with col:
        st.markdown(f"<div class='metric-card'><div class='metric-label'>{label}</div><div class='metric-value'>{value}</div><div class='metric-help'>{help_text}</div></div>", unsafe_allow_html=True)

st.write("")
strategy_name = t["strategy"].replace("_", " ").title()
st.markdown(f"<div class='info-card'><b>Suggested strategy: {escape(strategy_name)}</b><br><span class='muted'>{escape(t['strategy_about'])}</span><br><span class='muted'>Estimated BMR: {t['bmr']:,} kcal · Estimated daily energy use (TDEE): {t['tdee']:,} kcal · Eligible foods: {plan['foods_available']}</span></div>", unsafe_allow_html=True)
st.caption(f"Plan average: {plan['avg_calories']:,} kcal/day · Calorie-target match: {plan['calorie_accuracy_pct']}%. Estimates are approximate and may vary from actual nutritional needs.")

tab_plan, tab_week, tab_shop, tab_foods, tab_about = st.tabs(["🍽️ Meal plan", "📊 Nutrition dashboard", "🛒 Shopping list", "🥦 Food explorer", "ℹ️ Method & safety"])

with tab_plan:
    day_labels = [f"Day {d['day']}" for d in plan["days"]]
    selected_day_label = st.selectbox("Choose a day", day_labels, key="selected_day")
    selected_day = plan["days"][day_labels.index(selected_day_label)]
    daily = selected_day["totals"]
    st.markdown(f"#### {selected_day_label} · Your meals")
    pc = st.columns(4)
    for col, (label, value) in zip(pc, [("Calories", f"{daily['calories']:.0f} kcal"),("Protein",f"{daily['protein_g']:.1f} g"),("Carbs",f"{daily['carbs_g']:.1f} g"),("Fibre",f"{daily['fiber_g']:.1f} g")]):
        with col:
            st.metric(label, value)
    for meal in selected_day["meals"]:
        with st.container(border=True):
            top, kcal = st.columns([3, 1])
            with top:
                st.markdown(f"**{meal['meal']}**")
                st.caption(f"{len(meal['items'])} food items")
            with kcal:
                st.markdown(f"**{meal['totals']['calories']:.0f} kcal**")
            meal_df = pd.DataFrame([{
                "Food": r["food"], "Portion": f"{r['servings']:g} × {r['serving']}",
                "Calories": r["calories"], "Protein (g)": r["protein_g"],
                "Carbs (g)": r["carbs_g"], "Fat (g)": r["fat_g"], "Fibre (g)": r["fiber_g"]
            } for r in meal["items"]])
            st.dataframe(meal_df, hide_index=True, use_container_width=True)
    st.markdown("#### Daily calorie target")
    st.progress(min(1.0, daily["calories"] / max(1, t["calories"])), text=f"{daily['calories']:.0f} of {t['calories']} kcal estimated")
    st.download_button("Download this day as CSV", to_dataframe({**plan, "days": [selected_day]}).to_csv(index=False).encode("utf-8"), f"nutriwise_{selected_day_label.lower().replace(' ', '_')}.csv", "text/csv")

with tab_week:
    weekly = pd.DataFrame([{"Day": f"Day {d['day']}", "Planned calories": d["totals"]["calories"], "Daily target": t["calories"]} for d in plan["days"]])
    st.markdown("#### Calorie consistency")
    st.bar_chart(weekly.set_index("Day"), use_container_width=True)
    st.caption("Use this chart to compare planned calories across days with your estimated target. It is a planning aid, not a measure of health outcomes.")
    macro_keys = [("Protein", "protein_g", t["protein"]), ("Carbs", "carbs_g", t["carbs"]), ("Fat", "fat_g", t["fat"])]
    macro_rows = []
    for label, key, target in macro_keys:
        average = round(sum(d["totals"][key] for d in plan["days"]) / len(plan["days"]), 1)
        macro_rows.append({"Nutrient": label, "Average planned (g)": average, "Estimated target (g)": target})
    st.markdown("#### Average daily macronutrients")
    st.bar_chart(pd.DataFrame(macro_rows).set_index("Nutrient"), use_container_width=True)
    st.dataframe(pd.DataFrame([{"Day": f"Day {d['day']}", "Calories": d["totals"]["calories"], "Protein (g)": d["totals"]["protein_g"], "Carbs (g)": d["totals"]["carbs_g"], "Fat (g)": d["totals"]["fat_g"], "Fibre (g)": d["totals"]["fiber_g"]} for d in plan["days"]]), hide_index=True, use_container_width=True)

with tab_shop:
    shop = shopping_list(plan)
    st.markdown("#### Your combined shopping list")
    st.caption("Quantities are totals of the serving units used in the generated plan. Combine or adjust them to match package sizes and household needs.")
    if "checked_shop_items" not in st.session_state:
        st.session_state.checked_shop_items = []
    search_shop = st.text_input("Search shopping list", placeholder="e.g. oats, rice, milk")
    visible_shop = shop[shop["food"].str.contains(search_shop, case=False, na=False)] if search_shop else shop
    for _, item in visible_shop.iterrows():
        key = str(item["food"])
        checked = st.checkbox(f"{key} — {item['total_servings']:.2g} × {item['serving_size']}", value=key in st.session_state.checked_shop_items, key=f"shop_{key}")
        if checked and key not in st.session_state.checked_shop_items:
            st.session_state.checked_shop_items.append(key)
        elif not checked and key in st.session_state.checked_shop_items:
            st.session_state.checked_shop_items.remove(key)
    st.download_button("Download shopping list CSV", shop.to_csv(index=False).encode("utf-8"), "nutriwise_shopping_list.csv", "text/csv")
    st.download_button("Download full meal plan CSV", to_dataframe(plan).to_csv(index=False).encode("utf-8"), "nutriwise_meal_plan.csv", "text/csv")
    st.download_button("Download plan as Markdown", format_markdown(plan).encode("utf-8"), "nutriwise_meal_plan.md", "text/markdown")
    html_rows = "".join(f"<tr><td>Day {int(r.day)}</td><td>{escape(str(r.meal))}</td><td>{escape(str(r.food))}</td><td>{escape(str(r.amount))}</td><td>{int(r.calories)}</td></tr>" for r in to_dataframe(plan).itertuples())
    printable = f"<!doctype html><html><head><meta charset='utf-8'><title>NutriWise Meal Plan</title><style>body{{font:16px Arial,sans-serif;margin:36px;color:#19352b}}h1{{color:#176b52}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #d7e4dc;padding:8px;text-align:left}}th{{background:#eaf5ef}}.note{{color:#65766d;font-size:12px}}</style></head><body><h1>NutriWise — Personalised Diet Plan</h1><p>Daily target: {t['calories']} kcal · Protein {t['protein']} g · Carbs {t['carbs']} g · Fat {t['fat']} g</p><table><thead><tr><th>Day</th><th>Meal</th><th>Food</th><th>Portion</th><th>Calories</th></tr></thead><tbody>{html_rows}</tbody></table><p class='note'>{escape(DISCLAIMER)}</p><script>window.print()</script></body></html>"
    st.download_button("Download print-ready HTML", printable.encode("utf-8"), "nutriwise_printable_plan.html", "text/html")

with tab_foods:
    st.markdown("#### Browse foods in the recommendation dataset")
    food_search = st.text_input("Find a food", placeholder="Search by food name")
    food_df = rec.foods.copy()
    if food_search:
        food_df = food_df[food_df["name"].str.contains(food_search, case=False, na=False)]
    food_df = food_df.rename(columns={"name":"Food", "diet":"Diet category", "serving":"Serving size", "calories":"Calories", "protein_g":"Protein (g)", "carbs_g":"Carbs (g)", "fat_g":"Fat (g)", "fiber_g":"Fibre (g)", "sugar_g":"Sugar (g)", "sodium_mg":"Sodium (mg)", "gi":"GI label"})
    show_cols = [c for c in ["Food", "Diet category", "Serving size", "Calories", "Protein (g)", "Carbs (g)", "Fat (g)", "Fibre (g)", "Sugar (g)", "Sodium (mg)", "GI label"] if c in food_df.columns]
    st.dataframe(food_df[show_cols], hide_index=True, use_container_width=True)
    st.caption(f"Showing {len(food_df)} of {len(rec.foods)} foods. Values depend on the project's bundled dataset and may differ from product labels or recipes.")

with tab_about:
    st.markdown("#### How recommendations are generated")
    st.markdown("""
    1. **Energy estimate:** Basal metabolic rate is estimated using the Mifflin–St Jeor equation, then adjusted using the selected activity factor.
    2. **Goal adjustment:** The app estimates a calorie target for weight maintenance, loss or gain, with basic guardrails for younger users and low BMI.
    3. **Food filtering:** Foods are filtered against diet type, declared allergens, dislikes and simplified condition-related rules.
    4. **Strategy selection:** A Random Forest classifier selects a macro strategy using profile features. The included model was trained on synthetic rule-labelled profiles; it is a demonstration model, not a clinically validated decision system.
    5. **Meal construction:** A content-based ranking and portion-fitting routine builds meals and totals the nutrients from the bundled food dataset.
    """)
    st.warning("Safety note: This is an educational wellness project, not a medical device or a substitute for a registered dietitian. Food-allergen labels and nutrient data may be incomplete. Do not rely on this app for allergy safety or disease treatment. If you have a medical condition, are pregnant, are under 18, or have a history of disordered eating, consult a qualified health professional before changing your diet.")
    st.markdown("#### Project tools")
    st.markdown("Python · Streamlit · Pandas · NumPy · scikit-learn · Joblib")
    st.markdown("#### Model limitations")
    st.markdown("The model's strategy labels are generated from simplified rules with some noise. Its apparent performance on synthetic data does not establish real-world health benefits or personalised medical accuracy.")

st.markdown("---")
st.caption("NutriWise · AI-Based Personalised Diet Recommendation · Built for educational demonstration")
st.caption(DISCLAIMER)
