# NutriWise — AI-Based Personalised Diet Recommendation

A local, browser-based Streamlit application that creates an illustrative personalised meal plan from profile details, food preferences and the included food dataset.

## Features

- Profile inputs for age, biological sex, height, weight, activity level and goal.
- Vegan, vegetarian, eggetarian and non-vegetarian options.
- Filters for listed allergens, food dislikes and selected health considerations.
- Estimated BMI, BMR, TDEE, calorie and macronutrient targets.
- Machine-learning macro-strategy selector (Random Forest model; synthetic training labels).
- Portion-fitted meals across 1–7 days.
- Daily meal details, calorie overview, macro charts and nutrition tables.
- Searchable food dataset explorer.
- Searchable shopping list with session checklist.
- Export meal plan as CSV/Markdown and shopping list as CSV; printable HTML report.

## Requirements

- Python 3.10 or later recommended
- pip

## Run on Windows

1. Extract the ZIP to a folder.
2. Open PowerShell in that folder.
3. Create and activate a virtual environment (recommended):

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

4. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Start the application:

   ```powershell
   python -m streamlit run app.py
   ```

6. Open the local URL printed in the terminal, normally `http://localhost:8501`.

## Run automated tests

```powershell
python -m pytest -q
```

## Project structure

```text
diet-recommendation/
├── app.py                     # Streamlit dashboard
├── data/foods.csv             # Food/nutrition sample dataset
├── models/profile_model.joblib# Trained strategy classifier
├── src/
│   ├── nutrition.py           # Profile validation and nutrition targets
│   ├── profile_model.py       # ML strategy model
│   ├── recommender.py         # Food filtering and meal generation
│   ├── report.py              # Export and shopping-list helpers
│   └── main.py                # Optional command-line interface
├── tests/test_diet.py         # Automated tests
├── requirements.txt
└── README.md
```

## Important limitations

This is an educational prototype. The model is trained on synthetic profiles labelled by simplified rules; this is not clinical validation. Nutrition estimates depend on the bundled dataset and assumptions. Allergen and condition filters may be incomplete and must not be treated as medical safeguards. Users with medical conditions, pregnancy, eating-disorder history, or users under 18 should consult a qualified healthcare professional before making dietary changes.
